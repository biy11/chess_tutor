package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests;

/**
 * @author Lance [lvs1]
 * version 0.1 framework
 *
 * This class is for testing FR2 - Player Management
 */
public class PlayerManagement {

   /**
    * Test if Color is assigned and stays on player
    */
   public void testColorStaysOnPlayer(){

   }

   /**
    * Test if Position of piece is updated
    */
   public void testPiecePositionUpdated(){

   }

   /**
    * Test black piece is removed when captured
    * by white
    */
   public void testBlackPieceCapturedByWhite(){

   }

   /**
    * Test white piece is removed when captured
    * by black
    */
   public void testWhitePieceCapturedByBlack(){

   }

}
