package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests;

/**
 * @author Lance [lvs1]
 * version 0.1 framework
 *
 * This class is for testing FR9 - Quitting the Game
 */
public class QuitGame {
   /**
    * Test selecting the Quit Button
    * should display a confirm prompt
    */
   public void testQuitButton(){}

   /**
    * Test resuming the game from quit prompt
    */
   public void testResumeGameFromQuit(){}

   /**
    * Test confirming the quit button
    * should return to main menu
    */
   public void testConfirmQuit(){}
}
