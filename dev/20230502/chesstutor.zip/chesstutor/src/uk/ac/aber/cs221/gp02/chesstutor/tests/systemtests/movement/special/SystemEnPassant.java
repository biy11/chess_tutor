package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests.movement.special;public class SystemEnPassant {
}
