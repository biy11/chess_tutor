package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests;

/**
 * @author Lance [lvs1]
 * version 0.1 framework
 *
 * This class is for testing FR5 Movement
 */
public class Movement {
   //public void
}
