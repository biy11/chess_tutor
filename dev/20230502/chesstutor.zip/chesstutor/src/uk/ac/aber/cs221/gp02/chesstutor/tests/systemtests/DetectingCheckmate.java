package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests;

import uk.ac.aber.cs221.gp02.chesstutor.game.Board;
import uk.ac.aber.cs221.gp02.chesstutor.game.Game;
import uk.ac.aber.cs221.gp02.chesstutor.game.Player;
import uk.ac.aber.cs221.gp02.chesstutor.moves.MakeMove;

import static uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests.TestBoardGUI.board;

/**
 * @author Lance (lvs1)
 * version 0.1 framework
 *
 * This class is for testing FR7 - Detecting Checkmate
 */
public class DetectingCheckmate {
   private Game newGame(){
      Game obj = new Game();
      obj.setBlackPlayer("Lace");
      obj.setWhitePlayer("Wil");
      return obj;
   }
   private Game createEmptyBoard(){
      Game obj = newGame();
      obj.getBoard().clearBoard();
      return obj;
   }
   private Game createFoolsBoard(){
      Game obj = newGame();
      Player white = obj.getWhitePlayer();
      Player black = obj.getBlackPlayer();

      MakeMove.movePiece(obj.getBoard(), white, 6,5, 5,5);
      MakeMove.movePiece(obj.getBoard(), black, 1,4,2,4);
      MakeMove.movePiece(obj.getBoard(), white, 6,6,4,6);

      return obj;

   }

   private Game createScholarsBoard(){
      Game obj = newGame();
      Player white = obj.getWhitePlayer();
      Player black = obj.getBlackPlayer();

      MakeMove.movePiece(obj.getBoard(), white, 6,4,4,4);
      MakeMove.movePiece(obj.getBoard(), black, 1,4,3,4);
      MakeMove.movePiece(obj.getBoard(), white, 7,5,4,2);
      MakeMove.movePiece(obj.getBoard(), black, 0,1,2,2);
      MakeMove.movePiece(obj.getBoard(), white, 7,3,3,7);
      MakeMove.movePiece(obj.getBoard(), black, 0,6,2,5);

      return obj;

   }

   /**
    * Test if Black can Checkmate White
    */
   public void testBlackCheckmateWhite(){

   }
   /**
    * Test if White can Checkmate Black
    */
   public void testWhiteCheckmateBlack(){

   }

   /**
    * Fool's Checkmate
    */
   public void testFoolsCheckmate(){}

   /**
    * Scholar's Checkmate
    */
   public void testScholarsCheckmate(){}

   /**
    * Double Checkmate
    */
   public void testDoubleCheckmate(){}

}
