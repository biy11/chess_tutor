package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests;

/**
 * @author Lance [lvs1]
 * version 0.1 framework
 *
 * This class is for testing FR3 - Board Management
 */
public class BoardManagement {
   /**
    * Test board is displayed
    */
   public void testDisplayBoard(){

   }

   /**
    * Test the visual indication of white's
    * turn
    */
   public void testVisualWhiteStart(){

   }

   /**
    * Test the visual indication of black's
    * turn (after white)
    */
   public void testVisualBlackTurn(){

   }
}
