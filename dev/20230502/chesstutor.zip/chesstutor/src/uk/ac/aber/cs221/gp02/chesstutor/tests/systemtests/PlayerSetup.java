package uk.ac.aber.cs221.gp02.chesstutor.tests.systemtests;

/**
 * @author Lance [lvs1]
 * version 0.1 framework
 *
 * This class is for testing FR1 - Player Setup
 */
public class PlayerSetup {

   /**
    * Tests for prompt pop-up
    * Prompt asks player to either restore or start a game.
    */
   public void testPrompt(){
      
   }

   /**
    * Tests start new game button
    */
   public void testStartNewGame(){

   }

   /**
    * Tests restore previous game
    */
   public void testRestoreGame(){

   }

   /**
    * Tests for username input
    */
   public void testUserName(){

   }

   /**
    * Tests color assignment of player 1
    */
   public void testColorAssignment(){

   }
}
